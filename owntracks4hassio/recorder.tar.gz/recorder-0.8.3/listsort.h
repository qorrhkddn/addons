#ifndef _LISTSORT_INCL_
# define _LISTSORT_INCL_

#include "json.h"

JsonNode *listsort(JsonNode *list, int is_circular, int is_double);

#endif
